"""Parser for STL / LTB (ROSE localized string table formats).

From src/client/gamecommon/stringmanager.cpp:
  STL format:
    ReadPascalString (u8-len) = "ZNZIN_STLTBL" type tag
    uint32 language_count
    for each language:
      ReadPascalString (u8-len) = language name
      uint32 row_count
      for each row:
        ReadPascalString (u8-len) = key string
        ReadPascalString (u8-len) = value string
        ReadPascalString (u8-len) = comment string
"""
from dataclasses import dataclass, field
from typing import Dict, List
from ..reader import BinaryReader


@dataclass
class STLRow:
    key: str
    values: Dict[str, str] = field(default_factory=dict)
    comments: Dict[str, str] = field(default_factory=dict)


@dataclass
class STL:
    languages: List[str] = field(default_factory=list)
    rows: List[STLRow] = field(default_factory=list)
    _key_index: Dict[str, int] = field(default_factory=dict)

    def get(self, key: str, lang: str = "") -> str:
        idx = self._key_index.get(key)
        if idx is None:
            return ""
        row = self.rows[idx]
        if lang:
            return row.values.get(lang, "")
        # return first available language value
        for l in self.languages:
            v = row.values.get(l, "")
            if v:
                return v
        return ""


def parse(path: str) -> STL:
    r = BinaryReader.from_file(path)
    stl = STL()

    tag = r.pascal_str_u8()
    if tag not in ("ZNZIN_STLTBL", "STRTBL"):
        pass  # proceed anyway, some variants differ

    lang_count = r.u32()
    lang_names: List[str] = []

    # collect all rows keyed by row key per language
    all_langs_data: List[tuple] = []

    for _ in range(lang_count):
        lang = r.pascal_str_u8()
        lang_names.append(lang)
        stl.languages.append(lang)

        row_count = r.u32()
        rows_data: List[tuple] = []
        for _ in range(row_count):
            key = r.pascal_str_u8()
            value = r.pascal_str_u8()
            comment = r.pascal_str_u8()
            rows_data.append((key, value, comment))
        all_langs_data.append((lang, rows_data))

    # build unified row list from first language's keys
    if all_langs_data:
        first_lang, first_rows = all_langs_data[0]
        for i, (key, value, comment) in enumerate(first_rows):
            row = STLRow(key=key)
            row.values[first_lang] = value
            row.comments[first_lang] = comment
            stl.rows.append(row)
            stl._key_index[key] = i

        for lang, rows_data in all_langs_data[1:]:
            for i, (key, value, comment) in enumerate(rows_data):
                if i < len(stl.rows):
                    stl.rows[i].values[lang] = value
                    stl.rows[i].comments[lang] = comment

    return stl
